# server.R
library(shiny)
library(ggplot2)
library(leaflet)
library(dplyr)

#read the data
data = read.csv("subset.csv")
cluster_revenue = read.csv("TotalRevenuebyCluster.csv")
cluster_revenue$seller_cluster <- as.factor(cluster_revenue[,1])
data$seller_Cluster <- as.factor(data$seller_Cluster)

subset_1 <- data[1:1000,] #subset for testing 

#create icon format for each cluster
icons_1 <- awesomeIcons(
  icon = 'ios-close',
  iconColor = 'black',
  library = 'ion',
  markerColor = "red"
)

icons_2 <- awesomeIcons(
  icon = 'ios-close',
  iconColor = 'black',
  library = 'ion',
  markerColor = "green"
)

icons_3 <- awesomeIcons(
  icon = 'ios-close',
  iconColor = 'black',
  library = 'ion',
  markerColor = "blue"
)

icons_4 <- awesomeIcons(
  icon = 'ios-close',
  iconColor = 'black',
  library = 'ion',
  markerColor = "orange"
)

icons_0 <- awesomeIcons(
  icon = 'ios-close',
  iconColor = 'black',
  library = 'ion',
  markerColor = "gray"
)

# Filter the data for each cluster
cluster1 <- subset(data,seller_Cluster == "Cluster 1")
cluster2 <- subset(data,seller_Cluster == "Cluster 2")
cluster3 <- subset(data,seller_Cluster == "Cluster 3")
cluster4 <- subset(data,seller_Cluster == "Cluster 4 ")
cluster0 <- subset(data,seller_Cluster == "Cluster 0")

# Create the popup content for each marker
get_popup_content <- function(data) {
  paste0(
    "<b> Seller ID: ", data$seller_id, "</b>",
    "<br> Total Revenue:($)", data$sum_seller_revenue,
    "<br> City: ", data$seller_city,
    #"<br>",
    "<br> Cluster: ", data$seller_Cluster
    #"<br>Ofsted: ", ofsted_group_spdf@data$ofsted_rating,
    #"<br>Pupils: ", ofsted_group_spdf@data$pupil_count, " (2017)"
  )
}


server <- (function(input, output) {
  
  #Generate the map + markers
  output$mymap <- renderLeaflet({ # create leaflet map
    leaflet(data = data) %>%
      addTiles(
        urlTemplate = "//{s}.tiles.mapbox.com/v3/jcheng.map-5ebohr46/{z}/{x}/{y}.png", #using the API of the map format from mapbox 
        attribution = 'Maps by <a href="http://www.mapbox.com/">Mapbox</a>') %>%
      setView(lng = -43, lat = -20, zoom = 5) %>%
      addAwesomeMarkers(data = cluster1,lng =~ cluster1$geolocation_lng,lat = ~ cluster1$geolocation_lat,icon=icons_1,popup = ~get_popup_content(cluster1),group="Cluster 1") %>%
      addAwesomeMarkers(data = cluster2,lng =~ cluster2$geolocation_lng,lat = ~ cluster2$geolocation_lat,icon=icons_2,popup = ~get_popup_content(cluster2),group="Cluster 2") %>%
      addAwesomeMarkers(data = cluster3,lng =~ cluster3$geolocation_lng,lat = ~ cluster3$geolocation_lat,icon=icons_3,popup = ~get_popup_content(cluster3),group="Cluster 3") %>%
      addAwesomeMarkers(data = cluster4,lng =~ cluster4$geolocation_lng,lat = ~ cluster4$geolocation_lat,icon=icons_4,popup = ~get_popup_content(cluster4),group="Cluster 4") %>%
      addAwesomeMarkers(data = cluster0,lng =~ cluster0$geolocation_lng,lat = ~ cluster0$geolocation_lat,icon=icons_0,popup = ~get_popup_content(cluster0),group="Cluster 0") %>%
      addCircles(lng =~ data$geolocation_lng,lat = ~ data$geolocation_lat, ~ data$sum_seller_revenue, stroke = F, group = "Area")  %>%
      addLayersControl(
        overlayGroups = c("Cluster 0","Cluster 1", "Cluster 2", "Cluster 3","Cluster 4","Area"), # add these layers
                      options = layersControlOptions(collapsed = FALSE),position = "bottomleft") %>% 
      hideGroup(c("Cluster 0","Cluster 1","Cluster 2", "Cluster 4","Cluster 3"))  %>%  # turn these off by default
      showGroup(input$specific_bar) #show the input of cluster
  })
  
  
  
  #Revenue plot for each cluster
  output$seller_revenue_plot <- renderPlot({ 
    
    newdata <- cluster_revenue %>% filter(seller_cluster == input$specific_bar) #filter the data based on input
    
    ggplot(data =  newdata, aes(x = seller_cluster,y = avg_sum_seller_revenue, fill = input$specific_bar)) +
       geom_bar(stat="identity") +
       geom_text(aes(label=avg_sum_seller_revenue), vjust=1.6, color="white", size=8.5)+
       ggtitle("Average of Total Revenue") +
       labs(y="average revenue ($)", x = "Cluster name") +
       theme(legend.position = "none") 
  })
  
  #Proportion plot for each cluster
  output$seller_proportion_plot <- renderPlot({ 
  
    newdata <- cluster_revenue %>% filter(seller_cluster == input$specific_bar)  #filter the data based on input
    
    ggplot(data =  newdata, aes(x = seller_cluster,y = propotion_of_cluster,fill = input$specific_bar)) +
      geom_bar(stat="identity") +
      geom_text(aes(label=propotion_of_cluster), vjust=1.6, color="white", size=8.5)+
      ggtitle("   Proportion of Cluster") +
      labs(y="proportion (%)", x = "Cluster name") +
      theme(legend.position = "none") 
  })
})  

