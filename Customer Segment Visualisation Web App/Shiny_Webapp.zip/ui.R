# ui.R
library(shiny)
library(leaflet)

cluster_revenue = read.csv("TotalRevenuebyCluster.csv")
cluster_revenue$seller_cluster <- as.factor(cluster_revenue[,1])

# Define UI for application
shinyUI(bootstrapPage(
    div(class="outer",
        tags$style(type = "text/css", "html, body {width:100%;height:100%}"),
        tags$head(
        # Include our custom CSS
        includeCSS("styles.css")
    ),
    leafletOutput("mymap", width = "100%", height = "100%"),
    absolutePanel(id = "controls", class = "panel panel-default", fixed = TRUE,
                  draggable = TRUE, top = 60, left = "auto", right = 20, bottom = "auto",
                  width = 330, height = "auto", 
                  
                  h2("Cluster Exploration"),
                  
                  selectInput("specific_bar", "Pick a Specific Cluster To Highlight -- the descending order of cluster based on the average total revenue ", choices = unique(cluster_revenue$seller_cluster)),
    
                  plotOutput("seller_revenue_plot",height = 200,width = 250 ),
                  plotOutput("seller_proportion_plot",height = 200,width = 250))
    
        )
    )
)
    

